public class CommonUtility {

    public static String getAppName() {
        return "My Company App standard version";
    }
}